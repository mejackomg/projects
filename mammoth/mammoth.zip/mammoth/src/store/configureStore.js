import { createStore, applyMiddleware, combineReducers } from 'redux';
import thunkMiddleware from 'redux-thunk';
import {layoutReducer } from '../reducers/layout';
import {dataReducer } from '../reducers/chartData';
import {databaseReducer } from '../reducers/database.js';
import {authReducer } from '../reducers/auth.js';


import ApiClient from '../utils/ApiClient';
import createMiddleware from './middleware/clientMiddleware';
const client = new ApiClient();

const reducer = combineReducers(
  {
    layoutReducer,
    authReducer,
    dataReducer,
    databaseReducer,
  }
);

const createStoreWithMiddleware = applyMiddleware(
  thunkMiddleware,
  //logger,
  createMiddleware(client)
)(createStore);

export default function configureStore(initialState) {
  return createStoreWithMiddleware(reducer, initialState);
}
