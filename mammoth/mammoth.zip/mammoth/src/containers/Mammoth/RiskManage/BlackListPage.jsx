/**
 * Created by apple on 2017/2/7.
 */


import React ,{ Component, PropTypes } from 'react';

import {Table, TableBody, TableHeader, TableHeaderColumn, TableRow, TableRowColumn} from 'material-ui/Table';
import IconButton from 'material-ui/IconButton';
import withWidth, {LARGE, MEDIUM,SMALL}  from '../../../utils/withWidth';
import {List, ListItem} from 'material-ui/List';

import {Toolbar, ToolbarGroup, ToolbarSeparator, ToolbarTitle} from 'material-ui/Toolbar';
import { connect } from 'react-redux';
import CircularProgress from 'material-ui/CircularProgress';
import {
    darkBlack
} from 'material-ui/styles/colors';
import keys from 'object-keys';
import { is } from 'immutable';
import Paper from 'material-ui/Paper';
import TabMenuBar from '../UserAnalysis/TabMenuBar.jsx';
import ShopsSearchBar from '../Shops/ShopsSearchBar.jsx'
import ShopsNavigationBar from '../UserAnalysis/ShopsNavigationBar.jsx'

import {loadBlackList,addSystemLog} from '../../../reducers/database.js';
class BlackListPage extends React.Component
{
    constructor(props) {
        super(props);
        this.state = {
            page:1,
            pageLineCount:10,
            advancedSearch:false,
            searchText:'',
            showFilterResult:false,
        };
    }

    componentDidMount () {
        const { dispatch} = this.props;
        const {page,pageLineCount,searchText} = this.state;
        dispatch(loadBlackList(page,pageLineCount,searchText));
        dispatch(addSystemLog(this.props.user.userName,'查看黑名单页面'));
    }

    shouldComponentUpdate=(nextProps = {}, nextState = {}) => {
        return true;//false,页面不刷新数据
    }

    getStyles() {
        const styles = {
            searchBar: {
                zIndex: this.context.muiTheme.zIndex.appBar,//-1,
                backgroundColor: this.context.muiTheme.palette.accent2Color,//alternateTextColor,
                height: this.context.muiTheme.palette.desktopSubheaderHeight
            },
            content: {
                margin: this.context.muiTheme.spacing.desktopGutter,
                zIndex: 0,
            },
            contentWhenMedium: {
                // margin: `${this.context.muiTheme.spacing.desktopGutter * 2}px  ${this.context.muiTheme.spacing.desktopGutter * 3}px`,
                marginTop: this.context.muiTheme.spacing.desktopGutter * 2+this.context.muiTheme.spacing.desktopSubheaderHeight,
                marginBottom: this.context.muiTheme.spacing.desktopGutter * 2,
                marginLeft:this.context.muiTheme.spacing.desktopGutter * 3,
                marginRight:this.context.muiTheme.spacing.desktopGutter * 3,
            },
            fontSizeSpan:{
                // alignSelf:'center',
                flex:1,
                // textAlign:'center'
            }
        }
        if ( this.props.width === MEDIUM || this.props.width === LARGE )
            styles.content = Object.assign(styles.content, styles.contentWhenMedium);
        return styles;
    }

    handleMouseDown_SetPage=(page)=> {
        this.setState({page:page});
        const {dispatch} = this.props;
        const {pageLineCount,searchText} = this.state;
        dispatch(loadBlackList(page,pageLineCount,searchText));
        dispatch(addSystemLog(this.props.user.userName,'查看第'+page+'页的黑名单数据'));
    }

    handleMouseDown_setPageLineCount=(count)=>{
        this.setState({pageLineCount:count});
        const {dispatch} = this.props;
        const {page,searchText} = this.state;
        dispatch(loadBlackList(page,count,searchText));
        dispatch(addSystemLog(this.props.user.userName,'按每页'+count+'条数据查看黑名单页面'));
    }

    handleMouseDown_AdvancedSearch=()=> {
        this.setState({advancedSearch: !this.state.advancedSearch});
    }
    advancedSearch_AutoComplete =()=>{
        this.setState({advancedSearch: !this.state.advancedSearch});
        const {dispatch} = this.props;
        const {searchText,pageLineCount} = this.state;
        dispatch(loadBlackList(1,pageLineCount,searchText));
    }
    onUpdateInput_AutoComplete = (value)=>{
        const {dispatch} = this.props;
        const {pageLineCount} = this.state;
        if(value==''){
            this.setState({
                page:1,
                searchText:'',
                showFilterResult:false
            });
            dispatch(loadBlackList(1,pageLineCount,''));
        }else{
            this.setState({
                searchText:value
            });
        }
    }
    handleMouseDown_ClearSearch=()=> {
        this.setState({
            page:1,
            searchText: '',
            showFilterResult:false
        });
        const {dispatch} = this.props;
        const {pageLineCount} = this.state;
        dispatch(loadBlackList(1,pageLineCount,''));
    }
    onNewRequest_AutoComplete=(chosenRequest, index)=> {
        const {dispatch} = this.props;
        this.setState({
            page:1,
            searchText: chosenRequest,
            showFilterResult: true
        })
        const {pageLineCount} = this.state;
        dispatch(loadBlackList(1,pageLineCount,chosenRequest));
        dispatch(addSystemLog(this.props.user.userName,'输入'+chosenRequest+'查看黑名单页面'));
    }
    tableRender=(data,list)=> {
        const { page,pageLineCount } = this.state;
        return (
            <Table
                //height=300
                fixedHeader={true}
                bodyStyle={{minHeight:510}}
            >
                <TableHeader adjustForCheckbox={false} displaySelectAll={false}>
                    <TableRow>
                        <TableHeaderColumn style={{padding:'0px',width: 64,textAlign:'center'}}>序号</TableHeaderColumn>
                        {
                            list.map((column, key)=>
                                column.indexOf('id') != -1 ? null :
                                    <TableHeaderColumn key={key} style={{padding:'0px',width:column.indexOf('用户ID') >= 0?73:164,textAlign:'center'}}>
                                        {column}
                                    </TableHeaderColumn>
                            )
                        }
                    </TableRow>
                </TableHeader>
                <TableBody
                    displayRowCheckbox={false}
                    showRowHover={true}
                    //stripedRows={true}
                >
                    {data.map((row, index) =>
                        <TableRow key={index}>
                            <TableRowColumn
                                style={{padding:'0px',textAlign:'center',width: 35}}>{index + 1 + (page - 1) * pageLineCount}
                            </TableRowColumn>
                            {
                                list.map((column, key) =>
                                    column.indexOf('用户ID') != -1 ?
                                        <TableRowColumn key={key} style={{padding:'0px',textAlign:'center',width:40}}>
                                            {row[column]}
                                        </TableRowColumn>:
                                        <TableRowColumn key={key} style={{padding:'0px',textAlign:'center',width:90}}>
                                            {row[column]}
                                        </TableRowColumn>
                                )
                            }
                        </TableRow>
                    )}
                </TableBody>
            </Table>
        )
    }

    render( ) {
        const styles = this.getStyles();
        const {BlackListData,count} = this.props;
        let UsersColumnList = ['用户ID','上榜次数','平均点击次数','最近刷单时间','电话','注册时间','地址'];
        const { page,pageLineCount,searchText,showFilterResult } = this.state;
        return (
            <Paper style={{width:'90%',margin:'50 auto'}} zDepth={2}>
                <Toolbar>
                    <ToolbarGroup>
                        <ToolbarTitle text="黑名单"/>
                    </ToolbarGroup>
                </Toolbar>

                    <Toolbar style={styles.searchBar}>
                        <ShopsSearchBar
                            advancedSearch={this.advancedSearch_AutoComplete}
                            onNewRequest={this.onNewRequest_AutoComplete}
                            clearSearch={this.handleMouseDown_ClearSearch}
                            showCloseButton={showFilterResult}
                            onUpdateInput={this.onUpdateInput_AutoComplete}
                            searchText={searchText}
                            data={[]}
                        />
                        <ShopsNavigationBar pageCount={pageLineCount}  value={page} total={count}
                                            setPage={this.handleMouseDown_SetPage}
                                            setPageLineCount={this.handleMouseDown_setPageLineCount}/>
                    </Toolbar>

                {
                    BlackListData.length<0 ?
                        <div style={{display:'flex', justifyContent:'center'}}>
                            <CircularProgress style={{margin:80}} size={1.5}/>
                        </div>
                        :
                        this.tableRender(BlackListData,UsersColumnList)
                }
                {
                    this.props.loading &&
                    <div style={{display:'flex', justifyContent:'center'}}>
                        <CircularProgress style={{margin:-350}} size={1.5}/>
                    </div>
                }
            </Paper>
        );
    }
}
BlackListPage.propTypes = {
    dispatch:PropTypes.func.isRequired
};
BlackListPage.contextTypes = {
    muiTheme: React.PropTypes.object,
}
const mapStateToProps = (state) => {
    const { databaseReducer,layoutReducer,authReducer } = state;
    return {
        user: authReducer.user,
        BlackListData:databaseReducer.BlackList.BlackListData,
        count:databaseReducer.BlackList.count,
        loading:databaseReducer.loading,
        loaded:databaseReducer.loaded,
        panelVisible:layoutReducer.panelVisible,//勿删,传入TabMenuBar*/

    };
};
export default connect(
    mapStateToProps
)(withWidth( )(BlackListPage));


