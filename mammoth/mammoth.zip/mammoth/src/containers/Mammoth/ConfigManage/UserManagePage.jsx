/**
 * Created by Administrator on 2016-11-23.
 */
import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import ActiveTheme from '../../../mui-themes/active-theme.js';
import getMuiTheme from '../../../../node_modules/material-ui/styles/getMuiTheme';
import withWidth, {LARGE, MEDIUM,SMALL}  from '../../../utils/withWidth';

import Subheader from 'material-ui/Subheader';
import Divider from 'material-ui/Divider';
import FlatButton from 'material-ui/FlatButton';
import {Toolbar, ToolbarGroup, ToolbarSeparator, ToolbarTitle} from 'material-ui/Toolbar';
import {Table, TableBody, TableHeader, TableHeaderColumn, TableRow, TableRowColumn} from 'material-ui/Table';
import {Tabs, Tab} from 'material-ui/Tabs';
import Title from 'react-title-component';
import keys from 'object-keys';
import Snackbar from 'material-ui/Snackbar';
import Paper from 'material-ui/Paper';

import { loadTransTable,QueryUserManageTable,loadUserManagebyText,addSystemLog} from '../../../reducers/database.js';
import SearchBar from './SearchBar.jsx'
import NavigationBar from './NavigationBar.jsx'
import UserManageTable from './UserManageTable.jsx'
import UserEdit from './UserEdit.jsx'

class UserManagePage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            page: 1,
            pageLineCount: 10,
            searchText_Platform: '',
            isPlatformFilter: false,
            searchText_Src: '',
            isSrcTableFilter: false,
            searchText_Dst: '',
            isDstTableFilter: false,
            selectedRow:-1,
            snackbarOpen: false,
            snackbarMessage: '',
        };
    }

    getChildContext() {
        return ( {
            muiTheme: this.context.muiTheme,
        } );
    }

    componentDidMount() {
        const {searchText_Platform,searchText_Src,searchText_Dst} = this.state;
        const { dispatch } = this.props;
        dispatch(QueryUserManageTable(searchText_Platform,searchText_Src,searchText_Dst));
        dispatch(addSystemLog(this.props.user.userName,'查看用户管理页面'));
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.mappingUserData && this.props.mappingUserData != nextProps.mappingUserData) {
            this.setState({
                loading: false,
            });
            this.setState({
                snackbarOpen: true,
                snackbarMessage: "Database loaded successfully"
            });
        }
        else if (nextProps.operateUserResult && this.props.operateUserResult != nextProps.operateUserResult) {
            const {success,data,error} = nextProps.operateUserResult;

            this.setState({
                snackbarOpen: true,
                snackbarMessage: success ? "Database updated successfully" : "Failed to update database: " + error
            });

            this.props.dispatch(QueryUserManageTable('','',''));
        }
        else if (nextProps.operateUserError) {
            const {success,error} = nextProps.operateUserError;

            this.setState({
                snackbarOpen: true,
                snackbarMessage: error//success ? "Database added successfully" : "Failed to add database：" + error
            });
        }

    }

    handleMouseDown_SetPage = (page)=> {
        this.setState({page});
        this.props.dispatch(addSystemLog(this.props.user.userName,'查看第'+page+'页用户信息'));
    }

    handleMouseDown_setPageLineCount = (count)=> {
        this.setState({pageLineCount: count});
        this.props.dispatch(addSystemLog(this.props.user.userName,'按每页'+count+'条数据查看用户信息'));
    }



    onNewRequest_AutoComplete_Platform = (chosenRequest, index)=> {
        const {dispatch} = this.props;
        const {searchText_Src,searchText_Dst}=this.state;
        this.setState({
            searchText_Platform: chosenRequest,
            isPlatformFilter: true
        });
        dispatch(QueryUserManageTable(chosenRequest,searchText_Src,searchText_Dst));
        dispatch(addSystemLog(this.props.user.userName,'输入'+chosenRequest+'搜索查看用户管理页面'));
    }

    onNewRequest_AutoComplete_Src = (chosenRequest, index)=> {
        const {dispatch} = this.props;
        const {searchText_Platform,searchText_Dst}=this.state;
        this.setState({
            searchText_Src: chosenRequest,
            isSrcTableFilter: true
        });
        dispatch(QueryUserManageTable(searchText_Platform,chosenRequest,searchText_Dst));
        dispatch(addSystemLog(this.props.user.userName,'输入'+chosenRequest+'搜索查看用户管理页面'));
    }

    onNewRequest_AutoComplete_Dst = (chosenRequest, index)=> {
        const {dispatch} = this.props;
        const {searchText_Platform,searchText_Src}=this.state;
        this.setState({
            searchText_Dst: chosenRequest,
            isDstTableFilter: true
        });
        dispatch(QueryUserManageTable(searchText_Platform,searchText_Src,chosenRequest));
        dispatch(addSystemLog(this.props.user.userName,'输入'+chosenRequest+'搜索查看用户管理页面'));
    }


    handleMouseDown_ClearSearch_Platform = ()=> {
        this.setState({
            searchText_Platform: '',
            isPlatformFilter: false
        });
        const {dispatch} = this.props;
        const {searchText_Src,searchText_Dst}=this.state;
        dispatch(QueryUserManageTable('',searchText_Src,searchText_Dst));
    }

    handleMouseDown_ClearSearch_Src = ()=> {
        this.setState({
            searchText_Src: '',
            isSrcTableFilter: false
        });
        const {dispatch} = this.props;
        const {searchText_Platform,searchText_Dst}=this.state;
        dispatch(QueryUserManageTable(searchText_Platform,'',searchText_Dst));
    }



    handleMouseDown_ClearSearch_Dst = ()=> {
        this.setState({
            searchText_Dst: '',
            isDstTableFilter: false
        });

        const {dispatch} = this.props;
        const {searchText_Platform,searchText_Src}=this.state;
        dispatch(QueryUserManageTable(searchText_Platform,searchText_Src,''));
    }



    onRowSelection_Table=(key)=> {
        this.setState({selectedRow: key.length==0?-1:key[0]})
    }

    _handleUpdate_Refresh=()=>{
        this.setState({selectedRow: -1})

        this.props.dispatch(loadTransTable());
    }
    _handle_Close_Snackbar = () => {
        this.setState({snackbarOpen: false});
    };

    getStyles() {
        const styles = {
            searchBar: {
                zIndex: this.context.muiTheme.zIndex.appBar,//-1,
                //backgroundColor: this.context.muiTheme.palette.accent2Color,//alternateTextColor,
                height: this.context.muiTheme.palette.desktopSubheaderHeight
            },
            content: {
                margin: this.context.muiTheme.spacing.desktopGutter,
                //marginBottom:0
                //paddingTop: this.context.muiTheme.spacing.desktopSubheaderHeight,
            },

            contentWhenMedium: {
                margin: `${this.context.muiTheme.spacing.desktopGutter * 2}px  ${this.context.muiTheme.spacing.desktopGutter * 3}px`,
                //marginTop:this.context.muiTheme.spacing.desktopGutter
            },
        };

        if (this.props.width === MEDIUM || this.props.width === LARGE)
            styles.content = Object.assign(styles.content, styles.contentWhenMedium);

        return styles;
    }

    render() {
        const styles = this.getStyles()
        const {mappingUserData,platformTypeData,userTypeData} = this.props;
        const { page,pageLineCount,searchText_Platform,isPlatformFilter,
            searchText_Src,isSrcTableFilter,searchText_Dst,isDstTableFilter,selectedRow} = this.state;
        const pageConut = Math.ceil(mappingUserData.length / pageLineCount);

        return (
            <Paper style={styles.content}>
                <Title render={(previousTitle) => `Home - ${previousTitle}`}/>
                {/*<Subheader style={{fontSize:20,color:colors.darkBlack}}>票房评估</Subheader>
                 <Divider/>*/}
                <Toolbar>
                    <ToolbarGroup>
                        <ToolbarTitle text="用户管理"/>
                    </ToolbarGroup>
                </Toolbar>

                <UserEdit
                    platformTypeData={platformTypeData} userTypeData={userTypeData} selectedRow={selectedRow!=-1?mappingUserData[selectedRow]:null}
                    handleRefresh={this._handleUpdate_Refresh}
                />

                <Toolbar style={styles.searchBar}>
                    <SearchBar onNewRequest={this.onNewRequest_AutoComplete_Platform}
                               clearSearch={this.handleMouseDown_ClearSearch_Platform}
                               showCloseButton={isPlatformFilter}
                               searchText={searchText_Platform}
                               data={[]}
                               hintText='用户信息'
                    />
                    <SearchBar onNewRequest={this.onNewRequest_AutoComplete_Src}
                               clearSearch={this.handleMouseDown_ClearSearch_Src}
                               showCloseButton={isSrcTableFilter}
                               searchText={searchText_Src}
                               data={userTypeData.map(item=>item.user_type_name)}
                               hintText='用户类型'
                    />
                    <SearchBar onNewRequest={this.onNewRequest_AutoComplete_Dst}
                               clearSearch={this.handleMouseDown_ClearSearch_Dst}
                               showCloseButton={isDstTableFilter}
                               searchText={searchText_Dst}
                               data={platformTypeData.map(item=>item.platform_name)}
                               hintText='平台类型'
                    />
                    <NavigationBar pageCount={pageConut}
                                   setPage={this.handleMouseDown_SetPage}
                                   setPageLineCount={this.handleMouseDown_setPageLineCount}/>
                </Toolbar>

                <UserManageTable
                    data={mappingUserData}
                    page={page} pageLineCount={pageLineCount}
                    onRowSelection={this.onRowSelection_Table}
                    selectedRowIndex={selectedRow}
                />

                <Snackbar
                    open={ this.state.snackbarOpen }
                    message={ this.state.snackbarMessage }
                    autoHideDuration={ 15000 }
                    onRequestClose={ this._handle_Close_Snackbar}
                />
            </Paper>
        );
    }
}


UserManagePage.contextTypes = {
    muiTheme: React.PropTypes.object,
}

UserManagePage.childContextTypes = {
    muiTheme: React.PropTypes.object,
};

UserManagePage.propTypes = {
    //width:PropTypes.number.isRequired,
    //height:PropTypes.number.isRequired,
    dispatch:PropTypes.func.isRequired,
};

const mapStateToProps = (state) => {
    const { databaseReducer,authReducer  } = state;

    return {
        user: authReducer.user,
        platformTypeData: databaseReducer.ColumnListData.platformTypeData,
        userTypeData: databaseReducer.ColumnListData.userTypeData,
        mappingUserData: databaseReducer.userManageTableData.mappingUserData,
        operateUserResult:databaseReducer.operateUserResult,
        operateUserError:databaseReducer.operateUserError,
    };
};

export default connect(
    mapStateToProps
)(withWidth( )(UserManagePage));

