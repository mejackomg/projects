import React, { Component, PropTypes } from 'react';
import FlatButton from 'material-ui/FlatButton';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Clear from 'material-ui/svg-icons/content/clear';

export default class DialogItems extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            value:0,
            isToggled:false,
            expanded:0,
            clickProps:{
                display:'none',
                display1:'inline-block'
            },
            sum:0
        };
    }
    componentWillReceiveProps (nextProps) {
        if(nextProps.nowItem) {
            this.setState({
                value : nextProps.nowItem
            });
        }
    }
    handleEventChange = (event, index, value) => {
        const { indexKey, haddleChangeSteps, stepItems} = this.props;
        if(Array.indexOf(stepItems, value) > -1) {
            return;
        }
        this.setState({value});
        haddleChangeSteps(indexKey, value);
    };

    handleToggle = (event, toggle) => {
        this.setState({isToggled: toggle});
    };
    deleteItem = () => {
        const { indexKey, haddleRemoveSteps} = this.props;
        haddleRemoveSteps(indexKey);
    };

    onchange = ()=>{
        'inline-block' == this.state.clickProps.display ? this.setState({clickProps:{display:'none'}})
            :this.setState({clickProps:{display:'inline-block'}});
        'inline-block' == this.state.clickProps.display1 ? this.setState({clickProps:{display1:'none'}})
            :this.setState({clickProps:{display1:'inline-block'}});
    };
    render( ) {
        const {checkItems,indexKey,stepItems,nowItem} = this.props;
        return (
            <div>
                <div style={{display:'flex',height:'46px',padding:'5px',marginBottom:'10px',
                    backgroundColor:this.context.muiTheme.palette.accent2Color}}>
                    <div style={{height:'36px',width:"54px",
                        background: this.context.muiTheme.palette.primary1Color,
                        lineHeight:'36px',textAlign:'center',marginRight:'10px'}}>
                        {indexKey}
                    </div>
                    <SelectField
                        key={1}
                        value={nowItem}
                        onChange={this.handleEventChange}
                        underlineStyle={{borderColor: this.context.muiTheme.palette.accent1Color}}
                        maxHeight={200}
                    >
                        {
                            checkItems.map((item,key)=>(
                                Array.indexOf(stepItems, item.id) > -1 ?
                                <MenuItem value={item.id} key={key} primaryText={item.name} style={{mixWidth:'200px',width:'200px',background:'#eee',color:'#ccc'}}
                                />:
                                <MenuItem value={item.id} key={key} primaryText={item.name} style={{mixWidth:'200px',width:'200px'}}
                                />
                            ))
                        }
                    </SelectField>
                    {/*<IconButton onTouchTap={this.onchange} ref="Create" style={{display:this.state.clickProps.display1}}>*/}
                        {/*/!*<BorderColor />*!/*/}
                        {/*<Create />*/}
                    {/*</IconButton>*/}
                    {/*<input ref="input_custom" placeholder="自定义步骤名"*/}
                           {/*style={{width:'30%',border:'1px solid #a8b7c8',padding:'6px 10px 6px 10px',*/}
                               {/*fontSize:'14px',color:'#212121',borderRadius:'3px',*/}
                               {/*backgroundColor:'#fff',display:this.state.clickProps.display}}*/}
                    {/*>*/}

                    {/*</input>*/}
                    {/*<Toggle*/}
                    {/*label="自定义属性"*/}
                    {/*toggled={this.state.isToggled}*/}
                    {/*onToggle={this.handleToggle}*/}
                    {/*labelPosition="right"*/}
                    {/*style={{width:'130px',marginTop:"6px"}}*/}
                    {/*/>*/}
                    {/*<FlatButton label="触发限制条件"*/}
                                {/*labelPosition="after"*/}
                                {/*primary={true}*/}
                                {/*icon={<ContentAdd />}*/}
                        {/*//onTouchTap={isexpanded?this.handleReduce:this.handleExpand}*/}
                        {/*//onTouchTap={this.handleAdd}*/}
                                {/*style={{width:'144px'}} />*/}
                    {
                        indexKey>1?
                        <FlatButton label="删除"
                                labelPosition="after"
                                primary={true}
                                icon={<Clear />}
                                onTouchTap={this.deleteItem}
                        //onTouchTap={this.handleAdd}
                                style={{width:'36px'}} />
                                :null}
                </div>
                {/*<DialogChoose checkItems1={checkItems1} checkItems2={checkItems2}></DialogChoose>*/}
            </div>
        )
    }
}
DialogItems.contextTypes = {
    muiTheme: React.PropTypes.object,
}



