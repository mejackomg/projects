import 'babel-polyfill';

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import { isLoaded as isAuthLoaded, load as loadAuth } from './reducers/auth';
import configureStore from './store/configureStore';

import Chrome from './containers/WelcomePage/Chrome.jsx';
import Home from './containers/WelcomePage/HomeScreen.jsx';
import Mammoth from './containers/Mammoth/Chrome.jsx';
import NotFound from './containers/NotFound';
import User_Properties from './containers/UserManagement/User_Properties';
import User_UpdatePassword from './containers/UserManagement/User_UpdatePassword';
import DataTransforPage from './containers/Mammoth/ConfigManage/DataTransforPage.jsx'
import APIRecordPage from './containers/Mammoth/ConfigManage/APIRecordPage.jsx'
import SystemLog from './containers/Mammoth/ConfigManage/SystemLog.jsx'
import UserManagePage from './containers/Mammoth/ConfigManage/UserManagePage.jsx'

import ShopsProfile from './containers/Mammoth/Shops/ShopsProfile.jsx'
import ShopsRecord from './containers/Mammoth/Shops/ShopsRecord.jsx'
import ShopsPages from './containers/Mammoth/Shops/ShopsPage.jsx'

import UserProfile from './containers/Mammoth/UserAnalysis/UserProfile.jsx';
import UserRecord from './containers/Mammoth/UserAnalysis/UserRecord.jsx';
import UserPage from './containers/Mammoth/UserAnalysis/UserPage.jsx';

import RiskProfile from './containers/Mammoth/RiskManage/RiskProfile.jsx'
import ReportPage from './containers/Mammoth/Reports/ReportPage.jsx'

import FunnelAnalysis from './containers/Mammoth/BehaviorAnalysis/FunnelAnalysis.jsx'
import CriticalPath from './containers/Mammoth/BehaviorAnalysis/CriticalPath.jsx'
import EventAnalysis from './containers/Mammoth/BehaviorAnalysis/EventAnalysis.jsx'
import RetentionAnalysis from './containers/Mammoth/BehaviorAnalysis/RetentionAnalysis.jsx'

import BlackListPage from './containers/Mammoth/RiskManage/BlackListPage.jsx'
import IndexPage from './components/IndexPage'
// import Mixpanel from './components/mixpanel-node.js';


import './index.css';
import './styles.css';
import ShopLoanPage from './containers/Mammoth/Shops/ShopLoanPage.jsx'
import LoanAnalysis from './containers/Mammoth/Shops/LoanAnalysis.jsx'
require('./containers/Charts/china.js');
require('./containers/Charts/beijing.js');

require('./containers/Charts/theme/infographic')

import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin( );

// global.mixpanel = Mixpanel.init('6fd9434dba686db2d1ab66b4462a3000');

const store = configureStore();

const requireLogin = (nextState, replace, cb) => {
  function checkAuth() {
    const { authReducer: { user }} = store.getState();
    if (!user) {
      // oops, not logged in, so can't be here!
      replace('/');
    }
    cb();
  }

  if (!isAuthLoaded(store.getState())) {
    store.dispatch(loadAuth()).then(checkAuth);
  } else {
    checkAuth();
  }
};

ReactDOM.render(
  <Provider store={store}>
    <Router history={browserHistory}>
      <Route onEnter={requireLogin} path="mammoth" component={Mammoth}>
        <Route path="reports/:level1/:level2" component={IndexPage} />
        <Route path="user">
          <IndexRoute component={User_Properties} />
          <Route path="updatePassword" component={User_UpdatePassword} />
        </Route>
        <Route path="behavior">
          <IndexRoute component={FunnelAnalysis}/>
          <Route path="critical" component={CriticalPath} />
          <Route path="event" component={EventAnalysis}/>
          <Route path="retent" component={RetentionAnalysis} />
        </Route>
        <Route path="risk" >
          <Route path="blacklist" component={BlackListPage} />
        </Route>
        <Route path="configManage">
          <Route path="dataTransfor" component={DataTransforPage}/>
          <Route path="apiRecord" component={APIRecordPage}/>
          <Route path="systemLog" component={SystemLog}/>
          <Route path="userManage" component={UserManagePage}/>
        </Route>
        <Route path="shopsPages">
          <IndexRoute component={ShopsPages} />
          <Route path=":shopsId" component={ShopsProfile}/>
          <Route path="shopsRecord" component={ShopsRecord}/>
        </Route>
        <Route path="userpages">
          <IndexRoute component={UserPage} />
          <Route path=":usersId" component={UserProfile}/>
          <Route path="userRecord" component={UserRecord}/>
        </Route>
        <Route path="shopLoanPages">
          <IndexRoute component={ShopLoanPage} />
          <Route path=":shopsId" component={LoanAnalysis}/>
        </Route>

      </Route>
      <Route path="/" component={Chrome}>
        <IndexRoute component={Home} />
        <Route path="*" component={NotFound}/>
      </Route>

    </Router>
  </Provider>,
  document.getElementById('root')
);
